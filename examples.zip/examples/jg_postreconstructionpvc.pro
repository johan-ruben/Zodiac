PRO jg_PostReconstructionPVC

  compile_opt idl3
  
  dir = Routine_Dir()
  
  ;---Read reconstructed SPECT image
  oSrc = gs_Source.FromFile(dir + 'test_lu177_208.src')
  
  ;---Assume a Gaussian PSF with 4.9 mm FWHM. Convoltion should be perfomred via FFT.
  oPSF = gs_GaussianPSF(fwhm = 0.49, mode = 'fft', dataDims = [128, 128, 128], voxelSize = oSrc.voxelSize)
  
  ;---Create an object for Lucy-Richardson deconvolution and run 10 iterations of deconvolution
  oLucy = gs_LucyRichardson(oSrc, oPSF)
  oLucy.Run, 10, /verbose
  oLucy.oSrc.ToFile, dir + 'test_lu177_208_lrd.src', /compress, /overwrite
  
  ;---Create a basis of regional voxels with cosine perturbations. No perturbations in the background (default) and order 3 in the spheres
  ;The voxel size is one quarter of the source voxel size
  oReg = gs_RegionMap.FromFile(dir + 'spheres_background.reg')
  ii = Where(oReg.names.Matches('sphere'), nSpheres, /null)
  order = OrderedHash(oReg.names[ii], Replicate(3, nSpheres))
  oBasis = gs_FourierBasis(oReg, oSrc.voxelSize/[4, 4, 4], order = order)
  
  ;---Make a source described by the created basis. The emualted matrix size is the same as for the original source.
  oSrcB = gs_BasisSource(oSrc.imgData, emulateMatrix = oSrc.dataDims, basis = oBasis, /nonNegative, radionuclide = oSrc.radionuclide)
  
  ;---Make an object for region-perturbed Lucy-Richardson deconvolution and run for 4 iterations
  oRPLRD = gs_LucyRichardson(oSrcB, oPSF, oSrc)
  oRPLRD.Run, 4, /verbose
  oRPLRD.oSrc.ToFile, dir + 'test_lu177_208_lrd.bsrc', /compress, /overwrite
  
END