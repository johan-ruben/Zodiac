PRO jg_PolluxExampleLu

  compile_opt idl3
  
  ;Locate directory
  dir = Routine_Dir()
  
  ;Read projection data and store in a gs_StandardCameraProjections objects.
  ;Projection 1 is for the 208 keV window and projection 2 is for the 113 keV
  ;window. Sacle projections to 30 s and 100 MBq.
  
  prj1 = PoiDev(100.*Read_Binary(dir + 'spheres_tot_w1.a00', data_dims = [128, 128, 60], data_type = 4)*30., seed = seed)
  prj2 = PoiDev(100.*Read_Binary(dir + 'spheres_tot_w2.a00', data_dims = [128, 128, 60], data_type = 4)*30., seed = seed)
  
  oWins = [gs_EnergyWindow(192.4, 223.6), gs_EnergyWindow(104.525, 121.475)]
  oPrjs = [gs_StandardCameraProjections(prj1, pixSiz = [0.442, 0.442], prjTime = Replicate(30., 60), cor = DblArr(2, 60), prjDist = Replicate(16., 60), prjAngles = DindGen(60)*6. + 90., energyWindow = oWins[0],  /nonNegative), $
    gs_StandardCameraProjections(prj2, pixSiz = [0.442, 0.442], prjTime = Replicate(30., 60), cor = DblArr(2, 60), prjDist = Replicate(16., 60), prjAngles = DindGen(60)*6. + 90., energyWindow = oWins[1],  /nonNegative)]

  ;Read density map and store as gs_density. File data is in g/L and is rescaled to g/mL
  dns = Read_Binary(dir + 'density.dat', data_dims = [512, 512, 128], data_type = 2)/1000.
  oDens = gs_Density(dns, voxelSize = [0.1105, 0.1105, 0.442], /nonNegative)

  ;Define the radionuclide for the source
  oRNC = gs_ReadRadionuclide('lu177', lowerLimit = 75.)

  ;Make an initial estimate as a cylinder filled with 1.0. Store as gs_source
  src = Rebin(Double(Shift(Dist(128, 128), -64, -64) le 64.), 128, 128, 128)
  oSrc = gs_Source(src, voxelSize = Replicate(oPrjs[0].pixSiz[0], 3), radionuclide = oRNC, /nonNegative)

  ;Define an interpolator for the geometric transfomrations.
  oInt = gs_LinearInterpolator3D()

  ;The density map is in a rather small voxel size. Regrid to the same size as the SPECT image
  ;to speed up the reconstruction.
  oRgrd = gs_Regrider3D(voxelSize = oDens.voxelSize*[4, 4, 1], dataDims = oDens.dataDims/[4, 4, 1], interpolator = oInt)
  oDensRg = oRgrd.Apply(oDens)

  ;The geometrical transfromation for the reconstruction is an axial rotator.
  oRot = gs_AxialRotator(interpolator = oInt, stepSize = oPrjs[0].pixSiz[0])

  ;The geometry concists of water. Read mass-attenuation coefficients from file and store in
  ;a gs_AttenuationData object.
  oAcoeff = gs_AttenuationFromFile('h2o')
  oAttData = gs_AttenuationData(oAcoeff)

  ;There is just one material, so the whole image is a single region.
  oRegDns = gs_RegionMap(Replicate(1S, 128, 128, 128), names = ['h2o'], labels = [1S])

  ;Wrap the whole attenuationg eometry as a gs_MatterDistribution object
  ;The attenuating geomtry is filtered with a Gaussian filter with 1 cm FWHM.
  oMatter = gs_MatterDistribution(oDensRg, oRegDns, attCoeff = oAttData, filter = gs_GaussianFilter(fwhm = 1.0, nDimensions = 3, mode = 'fft'))

  ;Set up a gs_Attenautor object for modelling attenuation.
  oAttenuation = gs_Attenuator(densityDist = oMatter, transformer = oRot)
  
  ;Define a sensitivity object. There is a separate sensitivity for each energy window, but bohth are for 177Lu.
  ;Since these are the actual sensitivities for the simulated system, reconstructed images will be in MBq/mL.
  oSens = gs_Sensitivity([oPrjs[0].energyWindow, oPrjs[1].energyWindow], [oSrc.radionuclide, oSrc.radionuclide], [7.956, 6.053])
  
  ;Define the detector model from file. The scatter detector is the same model as for primaries but does not account for sensitivity differences. 
  oDet = gs_GeometricParallelDetector(dir + 'lu177.geo', pixelSize = oPrjs[0].pixSiz, stepSize = oPrjs[0].pixSiz[0], dataDims = oPrjs[0].mtxSiz, maxDist = 128.*oPrjs[0].pixSiz[0])
  oSdet = gs_GeometricParallelscatterDetector(dir + 'lu177.geo', pixelSize = oPrjs[0].pixSiz, stepSize = oPrjs[0].pixSiz[0], dataDims = oPrjs[0].mtxSiz, maxDist = 128.*oPrjs[0].pixSiz[0])
  
  ;Set up scatter modelling with ESSE. The scatter kernel is from Monte Carlo simulation of a point-source in water
  ;Note that the kernel i specific to the camera modelled and is NOT general for all cameras.
  oKrnl = jg_ScatterSource('C:\Users\johan\project\pollux_examples\point_avg.sca')
  oSS = gs_ConvolutionScatterSource(oDensRg, oRnc, kernels = oKrnl, padTo = [128, 128, 128], referenceDensity = 1.0, transformer = oRot)
  oESSE = gs_ESSE(scatterSource = oSS, attenuation = oAcoeff, sensitivity = oSens, detector = oSdet, priDetector = oDet)

  
  ;Define the full models for the pjojector and back-projector.
  oFwd = gs_InterpolationBasedProjector(transform = oRot, attenuation = oAttenuation, scatter = oESSE, detector = oDet, sensitivity = oSens)
  oBck = gs_InterpolationBasedBackProjector(transform = oRot, attenuation = oAttenuation, detector = oDet, sensitivity = oSens)

  ;Define the OS-EM reconstruction object with 10 subsets. Offload the normalization
  ;to temporary files.
  oRec = gs_OSEMreconstructor(oPrjs, oSrc, oFwd, oBck, nSubs = 10, /normInFile)

  ;Reconstruct with 4 iterations, printing a message after each subset.
  oRec.Run, 4, /verbose

  ;Save result to file
  oRec.oSrcs['source1'].ToFile, dir + 'test_lu177.src', /compress, /overwrite

END